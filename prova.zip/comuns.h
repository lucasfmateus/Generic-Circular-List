#ifndef COMUNS_H
#define COMUNS_H

#include <stdbool.h>

void imprime_char(void*);
bool compara_char(void*, void* c);
void imprime_int(void*);
bool compara_int(void*, void*);
void imprime_float(void*);
bool compara_float(void*, void*);
void imprime_double(void*);
bool compara_double(void*, void*);

#endif // COMUNS_H
